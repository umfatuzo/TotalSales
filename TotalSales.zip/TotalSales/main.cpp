#include <iostream>
#include <iomanip>

using namespace std;
using std::setw;
using std::setprecision;
using std::setiosflags;
using std::ios;

int main()
{
  const int PEOPLE = 5, PRODUCTS =6;
  double sales[ PEOPLE ] [ PRODUCTS ] = {0.0 }, value, totalSales, productSales [ PRODUCTS] = {0.0};
  int salesPerson, product;

  cout << "Enter the salesperson (1 - 4), product number (1 - 5),"
  << "and total sales.\nEnter -1 for the salesperson"
  << " to end input.\n";
  cin >> salesPerson;

  while ( salesPerson != -1 )
  {
      cin >> product >> value;
      sales[ salesPerson ] [product ] += value;
      cin >> salesPerson;
  }
  cout << "\nThe total sales for each salesperson are displayed"
  << " at the end of each row,\n" << "and the total sales for"
  << " each product are displayed at the bottom of each\n"
  << " column.\n " << setw( 12 ) << 1 << setw( 12 ) << 2 << setw( 12 ) << 3 << setw( 12 ) << 4 << setw( 12 ) << 5 << setw( 13)
  << "Total\n" << setiosflags( ios::fixed | ios::showpoint );

  for (int i = 1; i < PRODUCTS; i++ )
  {
      totalSales = 0.0;
      cout << i;

      for( int j =1; j < PRODUCTS; j++ )
      {
          totalSales += sales[ i ][ j ];
          cout << setw( 12 ) << setprecision( 2 ) << sales[ i ][ j ];
          productSales[ j ] +=sales [ i ][j ];
      }

      cout << setw( 12 ) << setprecision( 2 ) << totalSales << '\n';
  }
  cout << "\nTotal" << setw( 8 ) << setprecision( 2 ) << productSales[ 1 ];

  for( int j = 2; j < PRODUCTS; j++)
    cout << setw( 12 ) << setprecision( 2 ) << productSales[ j ];
  cout << endl;

  return 0;
  }
